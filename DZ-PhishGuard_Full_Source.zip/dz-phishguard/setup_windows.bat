@echo off
setlocal
cd /d "%~dp0"
echo =========================================
echo DZ-PhishGuard - Windows setup
echo =========================================
python --version >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
  echo During installation, check "Add python.exe to PATH".
  pause
  exit /b 1
)
if not exist .venv (
  python -m venv .venv
  if errorlevel 1 goto error
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto error
pip install -r requirements.txt
if errorlevel 1 goto error
if not exist models\dz_phishguard.joblib (
  echo Training the starter model...
  python train_model.py
  if errorlevel 1 goto error
)
echo.
echo Setup complete. Double-click run_windows.bat to launch the app.
pause
exit /b 0
:error
echo Setup failed. Copy the error text and share it for troubleshooting.
pause
exit /b 1
