"""Train and evaluate DZ-PhishGuard without group leakage."""
from __future__ import annotations
import argparse, csv, json, urllib.request, zipfile, io
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             average_precision_score, confusion_matrix, classification_report)
import joblib

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
MODELS = ROOT / 'models'
RESULTS = ROOT / 'results'

UCI_URL = 'https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip'

def load_data(include_uci: bool = False) -> pd.DataFrame:
    local = pd.read_csv(DATA / 'algerian_sms_synthetic.csv')
    local['label'] = local['label'].astype(int)
    local['source'] = 'synthetic_algerian'
    frames = [local[['text','label','group_id','language','source']]]
    if include_uci:
        raw_path = DATA / 'uci_sms_spam_collection.zip'
        if not raw_path.exists():
            print('Downloading UCI SMS Spam Collection...')
            urllib.request.urlretrieve(UCI_URL, raw_path)
        with zipfile.ZipFile(raw_path) as zf:
            member = next((n for n in zf.namelist() if n.lower().endswith('smsspamcollection')), None)
            if member is None:
                raise RuntimeError('Could not find SMSSpamCollection inside downloaded UCI archive.')
            raw = zf.read(member).decode('latin-1').splitlines()
        uci_rows=[]
        for i,line in enumerate(raw):
            if '\t' not in line: continue
            lab,msg=line.split('\t',1)
            uci_rows.append({'text':msg, 'label':1 if lab.strip().lower()=='spam' else 0,
                             'group_id':f'uci-{i}', 'language':'en', 'source':'UCI_SMS_Spam_Collection'})
        frames.append(pd.DataFrame(uci_rows))
    df = pd.concat(frames, ignore_index=True)
    df = df.dropna(subset=['text']).copy()
    df['text'] = df['text'].astype(str).str.strip()
    df = df[df['text'].str.len() > 2].drop_duplicates(subset=['text','label']).reset_index(drop=True)
    return df

def make_pipeline():
    features = FeatureUnion([
        ('word_tfidf', TfidfVectorizer(ngram_range=(1,2), min_df=1, max_features=16000,
                                      sublinear_tf=True, strip_accents=None, token_pattern=r'(?u)\b\w+\b')),
        ('char_tfidf', TfidfVectorizer(analyzer='char_wb', ngram_range=(3,5), min_df=1,
                                      max_features=26000, sublinear_tf=True, strip_accents=None)),
    ])
    return Pipeline([
        ('features', features),
        ('classifier', LogisticRegression(C=1.5, class_weight='balanced', max_iter=3000,
                                          solver='liblinear', random_state=42))
    ])

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--include-uci',action='store_true',help='Download and include the public UCI English SMS Spam Collection')
    args=parser.parse_args()
    MODELS.mkdir(exist_ok=True); RESULTS.mkdir(exist_ok=True)
    df=load_data(args.include_uci)
    X=df['text'].to_numpy(); y=df['label'].to_numpy(); groups=df['group_id'].to_numpy()
    if len(np.unique(y))<2: raise RuntimeError('Training data must contain both labels.')
    cv=StratifiedGroupKFold(n_splits=4,shuffle=True,random_state=42)
    train_idx,test_idx=next(cv.split(X,y,groups))
    Xtr,Xte=X[train_idx],X[test_idx]; ytr,yte=y[train_idx],y[test_idx]
    model=make_pipeline(); model.fit(Xtr,ytr)
    p=model.predict_proba(Xte)[:,1]
    pred=(p>=0.5).astype(int)
    majority=int(pd.Series(ytr).mode().iloc[0])
    base=np.full_like(yte,majority)
    metrics={
      'dataset_rows':int(len(df)), 'train_rows':int(len(train_idx)), 'test_rows':int(len(test_idx)),
      'train_groups':int(len(set(groups[train_idx]))), 'test_groups':int(len(set(groups[test_idx]))),
      'source_counts':{str(k):int(v) for k,v in df['source'].value_counts().to_dict().items()},
      'label_counts':{'legitimate':int((y==0).sum()),'scam':int((y==1).sum())},
      'test_label_counts':{'legitimate':int((yte==0).sum()),'scam':int((yte==1).sum())},
      'baseline':{'name':'majority-class baseline','predicted_class':'scam' if majority else 'legitimate',
                  'accuracy':float(accuracy_score(yte,base)),'precision_scam':float(precision_score(yte,base,zero_division=0)),
                  'recall_scam':float(recall_score(yte,base,zero_division=0)),'f1_scam':float(f1_score(yte,base,zero_division=0))},
      'model':{'name':'word + character TF-IDF with Logistic Regression',
               'accuracy':float(accuracy_score(yte,pred)), 'precision_scam':float(precision_score(yte,pred,zero_division=0)),
               'recall_scam':float(recall_score(yte,pred,zero_division=0)), 'f1_scam':float(f1_score(yte,pred,zero_division=0)),
               'average_precision':float(average_precision_score(yte,p))},
      'confusion_matrix_labels':['legitimate','scam'],
      'confusion_matrix':confusion_matrix(yte,pred,labels=[0,1]).tolist(),
      'evaluation_note':'One fold of StratifiedGroupKFold. Synthetic messages were drafted with AI assistance; this is a prototype benchmark, not a real-world field trial.'
    }
    errors=[]
    for idx, true, guessed, prob in zip(test_idx,yte,pred,p):
        if true != guessed:
            errors.append({'text':df.iloc[idx]['text'],'true_label':'scam' if true else 'legitimate',
                           'predicted_label':'scam' if guessed else 'legitimate','model_score_scam':round(float(prob),4),
                           'source':df.iloc[idx]['source'],'language':df.iloc[idx]['language']})
    metrics['misclassified_examples']=errors[:8]
    (RESULTS/'evaluation.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    # Refit final app model on all available rows after keeping the held-out evaluation above.
    final_model=make_pipeline(); final_model.fit(X,y)
    joblib.dump({'pipeline':final_model,'threshold':0.5,'training_rows':len(df),
                 'uses_uci':bool(args.include_uci),'model_name':'DZ-PhishGuard word+character TF-IDF / Logistic Regression'}, MODELS/'dz_phishguard.joblib')
    print(json.dumps({k:metrics[k] for k in ['dataset_rows','train_rows','test_rows','label_counts','baseline','model','confusion_matrix','misclassified_examples']},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
