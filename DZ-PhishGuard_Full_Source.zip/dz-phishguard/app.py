from __future__ import annotations
import re, json, html, unicodedata, os
from pathlib import Path
import joblib
os.environ.setdefault('GRADIO_ANALYTICS_ENABLED', 'False')
import gradio as gr

ROOT=Path(__file__).resolve().parent
MODEL_PATH=ROOT/'models'/'dz_phishguard.joblib'
METRICS_PATH=ROOT/'results'/'evaluation.json'
if not MODEL_PATH.exists():
    raise SystemExit('Model file is missing. Run: python train_model.py')
BUNDLE=joblib.load(MODEL_PATH)
MODEL=BUNDLE['pipeline']; THRESHOLD=float(BUNDLE.get('threshold',0.5))
try: METRICS=json.loads(METRICS_PATH.read_text(encoding='utf-8'))
except Exception: METRICS={}

ARABIC_NORMALIZE=str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','ة':'ة','ؤ':'و','ئ':'ي','ـ':''})

def normalize(text):
    text=unicodedata.normalize('NFKC',str(text)).translate(ARABIC_NORMALIZE)
    text=re.sub(r'[\u064b-\u065f\u0670]', '', text)
    return text.lower()

PATTERNS={
 'secret':re.compile(r'(otp|one.?time|cvv2?|cvc|pin|رمز\s*(التحقق|التاكيد|sms|السري)?|كود\s*(التحقق|sms)?|code\s*(de|sms|secret)?|mot de passe|password|كلمه السر|الرقم السري|رقم البطاقه|بيانات البطاقه|معلومات البطاقه|معلوماتك|بياناتك|معلوماتك البنكيه|بياناتك البنكيه|banking details|card details|account details|bank details|informations bancaires|coordonnees bancaires)',re.I),
 'request':re.compile(r'(ارسل|ترسل|ابعث|شارك|اعطني|اعطيني|صيفط|sifet|envoyez|envoyer|communiquez|send|share|reply with|reponds|répondez|اكتب|ادخل|اكد|أكد|تأكيد|حدث|تحديث|verify|confirm|update|validez|confirmez|vérifiez|saisissez|enter|provide)',re.I),
 'urgency':re.compile(r'(عاجل|فورا|فوراً|بسرعه|بسرعة|الان|الآن|خلال\s*\d+|اليوم|ساعة|دقيقه|دقيقة|immediatement|immédiatement|urgent|urgente|maintenant|vite|immediately|within\s*\d+|final warning|dernier avertissement|last warning|expire dans)',re.I),
 'impersonation':re.compile(r'(بريد الجزا(?:ئر|ير)|الجزائر بوست|alg[eé]rie\s*poste|baridi\s*mob|baridimob|edahabia|الذهبيه|البطاقة الذهبية|ccp|البنك|banque|bank|service client|خدمه الزبائن|الدعم التقني|support technique|security team|anti.?fraude)',re.I),
 'money':re.compile(r'(ادفع|دفع|رسوم|تحويل|حول|حوّل|مبلغ|دراهم|دج|da\b|paiement|payer|payez|frais|remboursement|virement|transfer|payment|fee|refund|claim your reward)',re.I),
 'threat':re.compile(r'(سيتم غلق|راح يتغلق|سيتم ايقاف|سيتم تعليق|حظر|تجميد|suspendu|bloque|bloqué|ferme|closed|disabled|lose access|permanently|عداله|العداله|justice|legal action)',re.I),
}
URL_RE=re.compile(r'(https?://\S+|www\.\S+|\b[a-z0-9][a-z0-9-]{1,}\.(?:com|net|org|info|site|xyz|top|example|online|click|app|dz)(?:/\S*)?)',re.I)
SAFE_NEGATION=re.compile(r'(لا\s*(تشارك|ترسل|تعطي|تعط|تبعث)|never\s+share|do not share|don.t share|ne communiquez jamais|ne partagez pas|لا تشارك)',re.I)

def analyze_indicators(message):
    t=normalize(message)
    has_secret=bool(PATTERNS['secret'].search(t))
    asks_for_secret=has_secret and bool(PATTERNS['request'].search(t)) and not bool(SAFE_NEGATION.search(t))
    has_url=bool(URL_RE.search(t))
    impersonation=bool(PATTERNS['impersonation'].search(t))
    urgency=bool(PATTERNS['urgency'].search(t))
    money=bool(PATTERNS['money'].search(t))
    threat=bool(PATTERNS['threat'].search(t))
    pts=0; items=[]
    if asks_for_secret: pts+=40; items.append(('طلب بيانات حساسة أو رمز تحقق','لا تشارك OTP أو PIN أو CVV أو بيانات البطاقة والحساب مع أي شخص.'))
    if has_url: pts+=25; items.append(('وجود رابط داخل الرسالة','لا تفتحه من الرسالة؛ افتح التطبيق الرسمي بنفسك.'))
    if impersonation: pts+=15; items.append(('انتحال أو ذكر جهة مالية موثوقة','ذكر اسم مؤسسة لا يثبت أن الرسالة صادرة عنها.'))
    if urgency: pts+=10; items.append(('ضغط زمني أو استعجال','الاستعجال المصطنع أسلوب شائع لدفع الضحية للتصرف دون تحقق.'))
    if money: pts+=10; items.append(('طلب دفع أو تحويل أو رسوم','تحقق من أي طلب مالي عبر قناة مستقلة.'))
    if threat: pts+=10; items.append(('تهديد بإيقاف الحساب أو فقدان الوصول','لا تستخدم رابط الرسالة لمعالجة التهديد.'))
    pts=min(100,pts)
    level='مرتفع' if pts>=65 else ('متوسط' if pts>=30 else 'منخفض')
    return {'score':pts,'level':level,'items':items,'asks_for_secret':asks_for_secret,'has_url':has_url}

def analyze(message):
    message=(message or '').strip()
    if len(message)<4:
        return '<div class="empty">أدخل نص الرسالة (4 أحرف على الأقل) حتى نحللها.</div>', '', 'أدخل رسالة أولًا.'
    prob=float(MODEL.predict_proba([message])[0][1])
    pred=int(prob>=THRESHOLD)
    signals=analyze_indicators(message)
    if pred==1:
        verdict='رسالة مشبوهة محتملة'; css='danger'; sub='النموذج وجد أنماطًا أقرب إلى رسائل الاحتيال في بيانات التدريب.'
    else:
        verdict='لم يكتشف النموذج نمط احتيال واضحًا'; css='safe'; sub='هذا لا يثبت أن الرسالة آمنة؛ قد تكون محاولة جديدة غير ممثلة في بيانات التدريب.'
    level=signals['level']
    items=''.join(f'<li><b>{html.escape(a)}</b><span>{html.escape(b)}</span></li>' for a,b in signals['items'])
    if not items: items='<li><b>لم تُلتقط إشارات واضحة من قواعد الفحص</b><span>افحص هوية المرسل والسياق يدويًا، ولا تشارك معلومات حساسة.</span></li>'
    score_color='high' if signals['score']>=65 else ('mid' if signals['score']>=30 else 'low')
    result=f'''<section class="result-card {css}">
      <div class="result-top"><div><div class="eyebrow">AI CLASSIFICATION</div><h2>{verdict}</h2><p>{sub}</p></div><div class="verdict-mark">{'!' if pred else '?'}</div></div>
      <div class="meter-row"><div class="meter-label">مؤشر النموذج للاحتيال</div><strong>{prob*100:.1f}%</strong></div>
      <div class="meter"><i style="width:{prob*100:.1f}%"></i></div>
      <div class="signal-line"><span>إشارات الخطر المستقلة</span><b class="{score_color}">{signals['score']}/100 · {level}</b></div>
      <hr/><div class="eyebrow">WHY IT WAS FLAGGED</div><ul class="signals">{items}</ul>
      <div class="advice"><b>الإجراء الآمن الآن</b><p>لا تفتح الرابط ولا ترسل OTP أو الرقم السري أو CVV. افتح التطبيق الرسمي بنفسك أو اتصل بالجهة عبر رقم موثوق تعرفه مسبقًا.</p></div>
      <div class="fineprint">قرار تجريبي للمساعدة في الفرز، وليس إثباتًا قاطعًا للاحتيال أو السلامة. قد يخطئ النموذج.</div>
    </section>'''
    plain=f"تصنيف الذكاء الاصطناعي: {'مشبوه محتمل' if pred else 'لم يكتشف نمطًا واضحًا'} | مؤشر النموذج: {prob*100:.1f}% | إشارات الخطر: {signals['score']}/100 ({level})"
    return result, plain, 'تم التحليل — لا تشارك بياناتك السرية.'


def metrics_html():
    m=METRICS.get('model',{}); b=METRICS.get('baseline',{}); cm=METRICS.get('confusion_matrix',[[0,0],[0,0]])
    if not m: return '<div class="metric-note">شغّل train_model.py لإظهار نتائج التقييم.</div>'
    return f'''<div class="metric-grid">
      <div class="metric"><small>Test messages</small><strong>{METRICS.get('test_rows','—')}</strong></div>
      <div class="metric"><small>Model accuracy</small><strong>{m.get('accuracy',0)*100:.1f}%</strong></div>
      <div class="metric"><small>Scam F1</small><strong>{m.get('f1_scam',0)*100:.1f}%</strong></div>
      <div class="metric"><small>Baseline accuracy</small><strong>{b.get('accuracy',0)*100:.1f}%</strong></div>
    </div><div class="metric-note">Scam precision: {m.get('precision_scam',0)*100:.1f}% · Scam recall: {m.get('recall_scam',0)*100:.1f}% · AP: {m.get('average_precision',0)*100:.1f}%. مصفوفة الالتباس (الحقيقة × التنبؤ): سليم→سليم {cm[0][0]} · سليم→احتيال {cm[0][1]} · احتيال→سليم {cm[1][0]} · احتيال→احتيال {cm[1][1]}. الاختبار على مجموعات منفصلة؛ النتائج الاصطناعية ليست دقة ميدانية.</div>'''

CSS='''
:root{--bg:#08111f;--panel:#101d30;--panel2:#14243a;--line:#263b55;--muted:#8ea4bd;--text:#eaf2fb;--teal:#39ddc5;--blue:#70a9ff;--red:#ff6b7a;--amber:#ffc568}
.gradio-container{background:radial-gradient(ellipse at 10% 0%,#102a45 0%,#08111f 48%,#060d18 100%)!important;color:var(--text)!important;font-family:Inter,'Segoe UI',Arial,sans-serif!important;max-width:1180px!important}
footer{display:none!important}.block,.form,.panel{background:transparent!important;border:0!important;box-shadow:none!important}
#hero{padding:34px 34px 26px;border:1px solid var(--line);border-radius:22px;background:linear-gradient(120deg,rgba(21,47,73,.96),rgba(12,25,43,.96));position:relative;overflow:hidden}
#hero:after{content:'DZ';position:absolute;right:35px;top:-26px;font-size:170px;font-weight:900;color:rgba(57,221,197,.055);letter-spacing:-18px}
.eyebrow{letter-spacing:2px;font-size:10px;font-weight:800;color:var(--teal);text-transform:uppercase}
#hero h1{font-size:42px;line-height:1.1;margin:12px 0 8px;color:#f5fbff;letter-spacing:-1.5px}
#hero p{max-width:700px;color:#b7c9dd;font-size:15px;line-height:1.8;margin:0}
.pills{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}.pill{font-size:11px;padding:7px 11px;border:1px solid #35536c;background:#10253b;border-radius:30px;color:#cde3f3}
.section-title{font-size:20px;font-weight:800;color:#eff7ff;margin:12px 0 5px}.hint{font-size:12px;color:var(--muted);margin:0 0 12px}
textarea{background:#0c192a!important;color:#eff7ff!important;border:1px solid #2b425e!important;border-radius:15px!important;font-size:15px!important;line-height:1.9!important}
button.primary{background:linear-gradient(100deg,#1ba995,#39ddc5)!important;color:#06131c!important;border:0!important;font-weight:900!important;border-radius:12px!important}
button.secondary{background:#142841!important;color:#d9eaff!important;border:1px solid #314f6d!important;border-radius:10px!important}
.result-card{border:1px solid var(--line);border-radius:18px;padding:22px;background:linear-gradient(160deg,#13243a,#0c192a);color:var(--text)}.result-card.danger{border-color:#7c3946}.result-card.safe{border-color:#28645d}
.result-top{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.result-card h2{font-size:22px;margin:8px 0;color:#f4f8fd}.result-card p{color:#aebfd1;line-height:1.65;font-size:13px}.verdict-mark{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;font-size:27px;font-weight:900;background:#2b354a;color:#ffc568}.danger .verdict-mark{background:#4a202b;color:#ff8995}.safe .verdict-mark{background:#173e39;color:#67e6ce}
.meter-row,.signal-line{display:flex;justify-content:space-between;align-items:center;margin-top:18px;color:#aebfd1;font-size:12px}.meter-row strong{font-size:18px;color:#f5fbff}.meter{height:8px;background:#26394f;border-radius:20px;overflow:hidden;margin-top:8px}.meter i{display:block;height:100%;background:linear-gradient(90deg,#2bbba9,#ffc568,#ff6476);border-radius:20px}.signal-line b{padding:6px 10px;border-radius:30px;background:#173d38;color:#69e4c9}.signal-line b.mid{background:#493920;color:#ffd27d}.signal-line b.high{background:#4b222c;color:#ff9aa4}
.result-card hr{border-color:#263b55;margin:20px 0}.signals{list-style:none;padding:0;margin:12px 0}.signals li{padding:11px 12px;margin:8px 0;background:#102037;border:1px solid #243b56;border-radius:11px}.signals b{display:block;color:#eaf3fc;font-size:12px}.signals span{display:block;color:#91a9c1;font-size:11px;margin-top:4px;line-height:1.6}.advice{margin-top:16px;border-left:3px solid var(--teal);background:#102d34;padding:12px 15px;border-radius:0 11px 11px 0}.advice b{color:#75eedb;font-size:12px}.advice p{margin:6px 0 0;color:#c6ddd9}.fineprint{font-size:10px;color:#8198b0;margin-top:14px;line-height:1.6}
.metric-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.metric{padding:16px;border:1px solid #29425c;background:#102138;border-radius:14px}.metric small{display:block;color:#91a9c1;font-size:11px}.metric strong{display:block;font-size:25px;color:#eaf7ff;margin-top:8px}.metric-note{font-size:11px;color:#91a9c1;margin-top:12px;line-height:1.8}.empty{padding:20px;background:#302a1b;color:#ffdc9d;border-radius:12px}.sample-box{background:#102138;border:1px solid #29425c;padding:12px;border-radius:12px;color:#c7d8e9;font-size:12px;line-height:1.7}.footnote{font-size:11px;color:#8096ad;text-align:center;padding:14px;line-height:1.7}
@media(max-width:700px){#hero{padding:24px 20px}#hero h1{font-size:32px}#hero:after{font-size:100px}.metric-grid{grid-template-columns:repeat(2,1fr)}}
'''

with gr.Blocks(title='DZ-PhishGuard | AI SMS Threat Triage') as demo:
    gr.HTML('''<div id="hero"><div class="eyebrow">ALGERIA · CYBER SAFETY · AI RESEARCH PROTOTYPE</div><h1>DZ-PhishGuard</h1><p>مساعد ذكي لتحليل رسائل التصيّد والاحتيال المالي. يفحص الأنماط اللغوية ومؤشرات الهندسة الاجتماعية، ثم يشرح أسباب الاشتباه بلغة واضحة — مع اهتمام خاص بالرسائل العربية والدارجة والفرنسية.</p><div class="pills"><span class="pill">Arabic · Darija</span><span class="pill">Français</span><span class="pill">English</span><span class="pill">Explainable ML</span><span class="pill">Privacy-first · Local processing</span></div></div>''')
    with gr.Row():
        with gr.Column(scale=6):
            gr.Markdown('### افحص رسالة مشبوهة',elem_classes=['section-title'])
            gr.Markdown('الصق نص الرسالة فقط. لا تضف رقم بطاقتك أو كلمة مرورك أو أي بيانات شخصية.',elem_classes=['hint'])
            message=gr.Textbox(lines=7,placeholder='مثال: بريد الجزائر: حسابك موقوف... / Votre compte sera bloqué... / baridimob ta3ek...',label='نص الرسالة')
            with gr.Row():
                run=gr.Button('حلّل الرسالة الآن',variant='primary',scale=3)
                clear=gr.ClearButton([message],value='مسح',variant='secondary',scale=1)
            status=gr.Markdown('')
            gr.Markdown('**جرّب أمثلة توضيحية**',elem_classes=['hint'])
            with gr.Row():
                sample1=gr.Button('رسالة تصيّد (عربي)',size='sm',variant='secondary')
                sample2=gr.Button('رسالة سليمة (عربي)',size='sm',variant='secondary')
                sample3=gr.Button('رسالة مشبوهة (Français)',size='sm',variant='secondary')
        with gr.Column(scale=7):
            gr.Markdown('### نتيجة التحليل',elem_classes=['section-title'])
            result=gr.HTML('<div class="sample-box">أدخل رسالة ثم اضغط «حلّل الرسالة الآن» لعرض النتيجة والتفسيرات.</div>')
            raw=gr.Textbox(label='ملخص نصي',interactive=False,visible=False)
    sample1.click(lambda: 'بريد الجزائر: حسابك موقوف مؤقتا. أكد معلوماتك عبر الرابط ap-update.example خلال 30 دقيقة لتجنب الغلق.',outputs=message)
    sample2.click(lambda: 'تم استلام تحويل بقيمة 3000 دج في حسابك. يمكنك مراجعة الرصيد من التطبيق الرسمي.',outputs=message)
    sample3.click(lambda: 'Votre compte bancaire sera bloqué. Envoyez le code reçu par SMS pour annuler la suspension sur banque-verif.example.',outputs=message)
    run.click(analyze,inputs=message,outputs=[result,raw,status])
    gr.Markdown('---')
    gr.Markdown('### نتائج التقييم التجريبي',elem_classes=['section-title'])
    gr.HTML(metrics_html())
    gr.Markdown('### ما الذي يميّز المشروع؟',elem_classes=['section-title'])
    gr.HTML('''<div class="metric-grid">
      <div class="metric"><small>01 · AI</small><strong>نموذج نصّي</strong><div class="metric-note">TF-IDF للكلمات والمحارف + Logistic Regression.</div></div>
      <div class="metric"><small>02 · LOCAL</small><strong>سياق جزائري</strong><div class="metric-note">أمثلة عربية ودارجة وفرنسية حول BaridiMob والبطاقة الذهبية.</div></div>
      <div class="metric"><small>03 · XAI</small><strong>تفسير واضح</strong><div class="metric-note">إشارات مستقلة تشرح طلب الأسرار والروابط والاستعجال والانتحال.</div></div>
      <div class="metric"><small>04 · SAFETY</small><strong>خصوصية</strong><div class="metric-note">التحليل محلي؛ لا حاجة إلى إرسال الرسالة إلى API خارجي.</div></div>
    </div>''')
    gr.HTML('<div class="footnote">مشروع طلابي تجريبي للمسابقة. لا يضمن اكتشاف كل عمليات الاحتيال ولا يثبت سلامة الرسالة. لا تشارك رموز OTP أو PIN أو CVV مع أي شخص. تحقق دائمًا عبر القنوات الرسمية التي تفتحها بنفسك.</div>')

demo.launch(server_name='127.0.0.1',server_port=7860,show_error=True,theme=gr.themes.Base(primary_hue='teal',secondary_hue='blue',neutral_hue='slate'),css=CSS)
