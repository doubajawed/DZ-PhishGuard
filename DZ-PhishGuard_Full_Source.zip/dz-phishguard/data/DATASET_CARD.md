# Dataset card — Algerian SMS synthetic starter set

## Summary
- 136 messages total: 72 synthetic scam/phishing examples and 64 synthetic legitimate examples.
- Languages/styles: Algerian Arabic / Darija, French and English, with a small set of Arabizi examples.
- Each row has `message_id`, `group_id`, `text`, `label`, `language`, and `origin`.
- `label=1` means suspicious/scam in the authored scenario; `label=0` means legitimate.

## How it was created
All 136 examples were synthetically drafted for this prototype with AI assistance and must be reviewed by the student team before submission. They are not scraped from victims, customer inboxes, or private accounts, and contain no personal data. The examples are designed around common social-engineering patterns such as fake account suspension, impersonation, OTP requests, fake delivery fees, prize claims, remote-access requests, and benign transaction/appointment notifications.

## Evaluation policy
Messages from the same scenario family share a `group_id`. The training script uses `StratifiedGroupKFold`, so messages from one scenario family are not split across training and test sets. This reduces the most obvious template leakage. The current set is small and synthetic, so the resulting scores are an internal prototype benchmark only. They must not be described as real-world detection accuracy.

## Known limitations
- It does not represent the full range of Algerian dialects, Arabizi spelling, French-Arabic code-switching, sender metadata, or real-world attacker adaptation.
- Synthetic writing can contain repeated stylistic patterns and may not match what real users receive.
- A model miss or false alarm is possible. The output is not proof that a message is malicious or safe.
- Do not add private messages or personal information without explicit consent and an appropriate data-protection process.

## Extension path
The training script supports `--include-uci`, which downloads and adds the public UCI SMS Spam Collection (5,574 English messages). That corpus is English and dates from older SMS research; it must be reported as a separate source and does not validate performance on current Algerian scams.

## Candidate corpus considered but not merged
A public Arabic SMS spam repository advertises 495 SMS rows with binary labels. On inspection, the spam class includes ordinary promotional and marketing messages as well as impersonation-style examples. Because broad spam is not the same target as financial phishing/smishing, we did not merge it into the current binary labels without re-annotation. See https://github.com/KhalidAlsantali/Arabic-SMS-Spam-Data and verify licensing/terms before any future use.
