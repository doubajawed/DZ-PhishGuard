# Data sources and selection notes

1. **Included training corpus:** `algerian_sms_synthetic.csv` — 136 AI-assisted synthetic messages created for this prototype; the student team should review every label before submission. This is not collected personal data and does not represent actual prevalence.
2. **Optional public extension:** UCI SMS Spam Collection, 5,574 English SMS messages. Project page: https://archive.ics.uci.edu/dataset/228/sms-spam-collection. It is older English data, so it cannot validate current Algerian-language performance by itself. It is not included in the starter metrics.
3. **Arabic SMS spam corpus considered, not merged:** https://github.com/KhalidAlsantali/Arabic-SMS-Spam-Data. Its 495 examples use a broad spam label and include promotional messages; these are not identical to financial phishing. Do not merge without inspecting the licensing and relabeling for the target task.

No real user messages, account identifiers, phone numbers, passwords, or OTPs are included in this project.
