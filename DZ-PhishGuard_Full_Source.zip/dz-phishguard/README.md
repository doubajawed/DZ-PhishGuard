# DZ-PhishGuard

An explainable, privacy-first AI prototype for triaging suspicious financial SMS messages in Algerian Arabic/Darija, French, English and Arabizi. Built for the Veritas AI International High School Hackathon 2026 — **AI + Finance**.

See [`README_AR.md`](README_AR.md) for complete Arabic setup instructions.

## Quick start
1. Install Python 3.11 or 3.12.
2. Run `setup_windows.bat` on Windows.
3. Run `run_windows.bat` and open `http://127.0.0.1:7860`.

## Method
A word + character TF-IDF feature pipeline with Logistic Regression provides the main machine-learning classification. A separate, transparent signal layer explains possible evidence: requests for secrets, links, impersonation, urgency, financial pressure and threats. The two scores are displayed separately.

## Starter evaluation (synthetic only)
136 AI-assisted synthetic messages; grouped holdout: 100 train / 36 test.
- Accuracy: 83.3%
- Scam precision: 88.9%
- Scam recall: 80.0%
- Scam F1: 84.2%
- Majority-class baseline accuracy: 55.6%
- Confusion matrix (true rows / predicted columns; legitimate, scam): `[[14, 2], [4, 16]]`

These are prototype results on a small synthetic dataset, not real-world accuracy. The model missed four scam examples and produced two false alarms in the held-out set. See `results/evaluation.json` and `data/DATASET_CARD.md`.

## Optional public-data extension
`python train_model.py --include-uci` downloads the 5,574-message English UCI SMS Spam Collection, merges it with the local synthetic examples, evaluates by grouped folds, and retrains the app model. Internet access is required. Report the exact data sources and new metrics if you use this mode.

## Intended user and impact
An Algerian resident receiving a message that claims to be from Algérie Poste, BaridiMob, or a financial service. The tool helps them pause, recognize social-engineering signals, and verify through a trusted channel they open independently.

## Safety
This is a prototype triage aid, not proof of fraud or safety. It does not block messages, access bank accounts, or contact institutions. Do not submit private messages containing personal information. Never share OTP, PIN, password, or CVV with anyone.

**This project is a prototype and is not financial advice.**
