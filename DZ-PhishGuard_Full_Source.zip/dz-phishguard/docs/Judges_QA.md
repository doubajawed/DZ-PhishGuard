# Questions judges may ask — suggested answers

**Why is this AI and not just keyword matching?**  
The main label comes from a trained Logistic Regression classifier over word and character TF-IDF features. Rules form a separate interpretation layer; they explain observable signals but do not replace the classifier.

**Why not use a large language model?**  
A lightweight local model is fast, reproducible, transparent enough to inspect, and does not send messages to an external API. A larger model could be compared later, but it would still need a rigorous local test set.

**Can you guarantee a message is safe?**  
No. “No pattern detected” is not proof of safety. The model can miss new wording and can produce false alarms. Users must verify independently.

**Are these real Algerian scam messages?**  
No. The packaged local corpus is synthetic and was drafted with AI assistance for this prototype; the student team must review its messages and labels before submission. We deliberately avoid collecting victims’ private messages. We need a larger reviewed dataset before making real-world performance claims.

**What is the main limitation?**  
The local dataset is small and synthetic. It cannot represent all Algerian dialects, code-switching, sender identity, URL reputation, or new attacker tactics. The model missed four scam test examples and falsely flagged two legitimate ones.

**What did you contribute beyond the suggested scam filter?**  
We selected a specific Algerian user and context, added Arabic/Darija/French/Arabizi scenarios, focused on BaridiMob and Edahabia impersonation, separated explainable security signals from the ML score, and designed the tool to process messages locally.

**What is next?**  
Add a public corpus for training, report separate performance by language and data source, collect consent-based local evaluation examples, and test whether a safer threshold reduces missed scam cases without creating too many false alarms.


**Why did you not directly merge the public 495-row Arabic SMS spam dataset?**  
We inspected it as a candidate source. Its labels cover broad SMS spam and ordinary promotional/marketing messages, not only financial phishing. For our target label, merging it without reviewing and relabeling examples could contaminate the scam class. We therefore kept our current labels narrowly tied to the authored financial-smishing scenarios. The candidate corpus should only be used after checking the label definitions and licensing and, ideally, relabeling the relevant messages.
