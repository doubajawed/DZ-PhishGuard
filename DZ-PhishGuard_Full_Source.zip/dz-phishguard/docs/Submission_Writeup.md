# DZ-PhishGuard
**Track:** AI + Finance  
**Team details:** Entered separately in the submission form; keep names and school out of the blind-review write-up.  
**Project type:** Extension of the suggested scam-text-filter problem, localized for Algerian users

## The problem
An Algerian resident may receive an SMS pretending to come from Algérie Poste, BaridiMob, or another financial service. The message may pressure them to click a link, share a one-time password, disclose card details, or pay an urgent fee. Many people need more than a spam label: they need a clear explanation of the warning signs and a safe next action.

## What we built
DZ-PhishGuard is a local web prototype. A user pastes a message in Arabic, Algerian Darija, French, English, or Arabizi. A machine-learning classifier estimates whether the message resembles scam examples. A separate explainable signal layer highlights possible OTP/PIN/CVV requests, links, impersonation, urgency, threats, and financial pressure. The tool then recommends verifying through a trusted channel opened independently. Messages are processed locally; no external AI API is called.

## What we added
We focused on one local user and setting: Algerian people receiving financial-service messages, especially messages mentioning BaridiMob, Algérie Poste, and the Edahabia card. We added multilingual and Arabizi examples, an explanation layer, a privacy-first local interface, and a separate score for observable warning signals. We also report model errors instead of presenting the tool as perfect.

## How it works
**Data:** The packaged starter model uses 136 AI-assisted synthetic messages created specifically for this prototype: 72 scam scenarios and 64 legitimate scenarios. The team should review every label before submission. No private messages or personal data were used. The messages cover Arabic/Darija, French, English, and Arabizi. Rows from the same scenario family share a group ID. We use a stratified group split so a scenario family is not divided between training and testing.

**Model:** Word-level and character-level TF-IDF features are combined with Logistic Regression. Character patterns help handle spelling variation; word patterns capture common phrases. A separate transparent rule layer explains signals but does not replace the ML classifier.

## Results
On the held-out test fold (36 messages; 100 used for training):

| Measure | Majority-class baseline | DZ-PhishGuard |
|---|---:|---:|
| Accuracy | 55.6% | 83.3% |
| Scam precision | 55.6% | 88.9% |
| Scam recall | 100.0% | 80.0% |
| Scam F1 | 71.4% | 84.2% |

The model confusion matrix (true rows; predicted columns; legitimate, scam) was `[[14, 2], [4, 16]]`. It missed four scam messages and produced two false alarms. One missed example was: “We blocked a transfer. Reply with your one-time passcode to cancel it and secure your account.” We think the small dataset and the limited English examples caused this miss. One false alarm was a benign customer-service-hours message; overlapping finance vocabulary may have influenced the prediction.

**Interpretation:** These are preliminary results on a small synthetic benchmark, not real-world accuracy and not evidence that the model is ready to protect live bank users. The sample is too small to make reliable claims across languages or user groups.

## What we would do next
1. Add and separately evaluate the public UCI SMS Spam Collection (5,574 English messages), then report performance separately for the English public corpus and the Algerian synthetic scenarios.
2. Work with consenting Algerian volunteers or a trusted institution to create a larger, carefully reviewed, privacy-preserving local evaluation set; measure false positives and false negatives by language and message type.

## Sources and credits
- Synthetic Algerian-context messages: generated for this prototype with AI assistance and requiring team review; no real user messages.
- UCI SMS Spam Collection: Almeida & Hidalgo, UCI Machine Learning Repository, https://archive.ics.uci.edu/dataset/228/sms-spam-collection. This is an optional extension and is **not** included in the results above.
- Model and interface: scikit-learn, Gradio, pandas, joblib.
- AI assistance: ChatGPT was used to assist with synthetic-example drafting, code drafting, documentation, and debugging. The team must review and understand all submitted code.

**This project is a prototype and is not financial advice.** It does not prove that a message is fraudulent or safe, and it must not be used to block transactions automatically.
