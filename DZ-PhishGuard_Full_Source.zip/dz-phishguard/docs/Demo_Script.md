# 90–110 second demo script

**0:00–0:15 — The problem**  
“An Algerian user receives a message claiming to be from BaridiMob. It says the account will be blocked and asks for a code. A simple spam label does not explain the danger or what the user should do next.”

**0:15–0:45 — Live demo**  
Open DZ-PhishGuard. Select the Arabic phishing example and click Analyze. Point to the model classification, then to the independent indicators: link, institution impersonation, and urgency. Show the safe-action guidance. Next, select the legitimate transfer notification and analyze it. Explain that the tool does not treat every mention of a bank or BaridiMob as fraud.

**0:45–1:10 — How it works and results**  
“The core AI is a word-and-character TF-IDF model with Logistic Regression. We compare it with a majority-class baseline on a held-out group split. On our current small synthetic test set, the model reached 83.3% accuracy, 88.9% scam precision, and 80.0% scam recall, compared with 55.6% baseline accuracy.”

**1:10–1:30 — Honesty and next step**  
“Our examples are AI-assisted synthetic scenarios, so these numbers are not real-world accuracy. The model missed four scam messages and made two false alarms. One miss was a message asking for a one-time passcode. Next, we will expand the dataset with public English SMS data and build a reviewed Algerian evaluation set with consent.”

**Closing line**  
“DZ-PhishGuard does not replace a bank or an official authority. It helps users pause, recognize manipulation, and verify safely.”

## Recording checklist
- Record the actual running app, not mock screenshots.
- Show one suspicious and one legitimate input.
- Show the evaluation panel and at least one actual error from `results/evaluation.json`.
- Keep the recording under two minutes.
- Do not show any real phone number, personal account, password, OTP, or private message.
